import { useSelector } from 'react-redux';
import type { RootState } from '@/store';
import { User, Mail, Phone, MapPin, Briefcase, UserCircle } from 'lucide-react';

export default function ComponentB() {
  const employee = useSelector((state: RootState) => state.employee);

  const isEmpty =
    !employee.name &&
    !employee.email &&
    !employee.phone &&
    !employee.city &&
    !employee.role;

  if (isEmpty) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Employee Profile</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Submitted employee details will appear here.
          </p>
        </div>
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <UserCircle className="w-16 h-16 text-gray-300" />
          <p className="text-sm text-gray-400 mt-4">
            No employee data saved yet.
          </p>
        </div>
      </div>
    );
  }

  const fields = [
    { icon: User, label: 'Name', value: employee.name },
    { icon: Mail, label: 'Email', value: employee.email },
    { icon: Phone, label: 'Phone Number', value: employee.phone },
    { icon: MapPin, label: 'City', value: employee.city },
    { icon: Briefcase, label: 'Role', value: employee.role },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="bg-gradient-to-r from-sky-600 to-sky-700 px-6 py-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
            <User className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">{employee.name}</h2>
            <p className="text-sm text-sky-100">{employee.role}</p>
          </div>
        </div>
      </div>

      <div className="p-6 sm:p-8">
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-4">
          Contact Details
        </h3>
        <dl className="space-y-4">
          {fields.map((field) => (
            <div key={field.label} className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-sky-50 flex items-center justify-center flex-shrink-0">
                <field.icon className="w-4 h-4 text-sky-600" />
              </div>
              <div className="min-w-0">
                <dt className="text-xs text-gray-400">{field.label}</dt>
                <dd className="text-sm font-medium text-gray-800 truncate">
                  {field.value}
                </dd>
              </div>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}
