import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface EmployeeState {
  name: string;
  email: string;
  phone: string;
  city: string;
  role: string;
}

const initialState: EmployeeState = {
  name: '',
  email: '',
  phone: '',
  city: '',
  role: '',
};

const employeeSlice = createSlice({
  name: 'employee',
  initialState,
  reducers: {
    saveEmployee: (_state, action: PayloadAction<EmployeeState>) => {
      return action.payload;
    },
  },
});

export const { saveEmployee } = employeeSlice.actions;
export default employeeSlice.reducer;
