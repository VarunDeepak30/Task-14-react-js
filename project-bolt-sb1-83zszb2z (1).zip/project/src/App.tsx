import ComponentA from '@/components/ComponentA';
import ComponentB from '@/components/ComponentB';
import { Users } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="w-10 h-10 rounded-xl bg-sky-600 flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Employee Manager</h1>
          </div>
          <p className="text-sm text-gray-500">
            Register employees and view their profiles in one place.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ComponentA />
          <ComponentB />
        </div>
      </div>
    </div>
  );
}

export default App;
